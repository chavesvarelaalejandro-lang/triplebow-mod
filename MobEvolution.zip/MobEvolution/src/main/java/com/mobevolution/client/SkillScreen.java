package com.mobevolution.client;

import com.mobevolution.network.Network;
import com.mobevolution.network.UpgradePacket;
import com.mobevolution.skills.PlayerSkills;
import com.mobevolution.skills.Skill;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class SkillScreen extends Screen {
    private final Map<Skill, Button> buttons = new EnumMap<>(Skill.class);

    public SkillScreen() {
        super(Component.literal("Arbol de habilidades"));
    }

    @Override
    protected void init() {
        int right = this.width / 2 + 120;
        int y = this.height / 2 - 60;
        for (Skill s : Skill.values()) {
            Button b = Button.builder(Component.literal("+"),
                            btn -> Network.CHANNEL.sendToServer(new UpgradePacket(s)))
                    .bounds(right, y - 4, 20, 20).build();
            buttons.put(s, addRenderableWidget(b));
            y += 28;
        }
    }

    @Override
    public void tick() {
        PlayerSkills d = ClientSkillData.DATA;
        buttons.forEach((s, b) -> b.active = d.canUpgrade(s));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        renderBackground(g);
        PlayerSkills d = ClientSkillData.DATA;
        int left = this.width / 2 - 130;
        int y = this.height / 2 - 60;

        g.drawCenteredString(this.font, this.title, this.width / 2, this.height / 2 - 100, 0xFFFFFF);
        g.drawCenteredString(this.font, "Puntos disponibles: " + d.getPoints() + "  (1 por cada nivel de XP nuevo)",
                this.width / 2, this.height / 2 - 82, 0xFFD700);

        for (Skill s : Skill.values()) {
            g.drawString(this.font, s.displayName + "  " + d.getLevel(s) + "/" + s.maxLevel, left, y - 4, 0xFFFFFF);
            g.drawString(this.font, s.description, left, y + 6, 0xA0A0A0);
            y += 28;
        }
        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
