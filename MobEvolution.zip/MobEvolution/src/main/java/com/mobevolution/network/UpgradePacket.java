package com.mobevolution.network;

import com.mobevolution.skills.PlayerSkillsProvider;
import com.mobevolution.skills.Skill;
import com.mobevolution.skills.SkillEffects;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Cliente -> servidor: "quiero subir esta habilidad". El servidor valida todo. */
public class UpgradePacket {
    private final int skillOrdinal;

    public UpgradePacket(Skill s) { this.skillOrdinal = s.ordinal(); }
    private UpgradePacket(int o) { this.skillOrdinal = o; }

    public static void encode(UpgradePacket m, FriendlyByteBuf b) { b.writeVarInt(m.skillOrdinal); }
    public static UpgradePacket decode(FriendlyByteBuf b) { return new UpgradePacket(b.readVarInt()); }

    public static void handle(UpgradePacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp == null || m.skillOrdinal < 0 || m.skillOrdinal >= Skill.values().length) return;
            Skill skill = Skill.values()[m.skillOrdinal];
            sp.getCapability(PlayerSkillsProvider.CAP).ifPresent(s -> {
                if (s.tryUpgrade(skill)) {
                    SkillEffects.apply(sp);
                    Network.sync(sp);
                }
            });
        });
        ctx.get().setPacketHandled(true);
    }
}
