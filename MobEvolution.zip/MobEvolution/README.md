# Mob Evolution (Forge 1.20.1)

## Como compilarlo
1. Descarga el MDK de Forge 1.20.1 (47.3.0 o superior): https://files.minecraftforge.net/
2. Descomprimelo y BORRA su carpeta `src/main/java/com/example`.
3. Copia la carpeta `src` de este proyecto encima de la `src` del MDK
   (sustituye `META-INF/mods.toml` y `pack.mcmeta`).
4. En `gradle.properties` del MDK pon:
       mod_id=mobevolution
       mod_name=Mob Evolution
       mod_group_id=com.mobevolution
       mod_version=1.0.0
5. Necesitas JDK 17. Ejecuta `./gradlew build` (o `gradlew.bat build` en Windows).
6. El .jar queda en `build/libs/`. Metelo en la carpeta `mods` (cliente y servidor).

## Configuracion
`config/mobevolution-common.toml` (se genera al primer arranque).
