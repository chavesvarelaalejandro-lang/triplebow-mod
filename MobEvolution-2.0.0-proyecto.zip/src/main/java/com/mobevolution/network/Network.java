package com.mobevolution.network;

import com.mobevolution.MobEvolution;
import com.mobevolution.skills.PlayerSkillsProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class Network {
    private static final String PROTOCOL = "2";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MobEvolution.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private Network() {}

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, ApplyPacket.class, ApplyPacket::encode, ApplyPacket::decode, ApplyPacket::handle);
        CHANNEL.registerMessage(id++, ResetPacket.class, ResetPacket::encode, ResetPacket::decode, ResetPacket::handle);
        CHANNEL.registerMessage(id++, SyncPacket.class, SyncPacket::encode, SyncPacket::decode, SyncPacket::handle);
    }

    public static void sync(ServerPlayer sp) {
        sp.getCapability(PlayerSkillsProvider.CAP).ifPresent(s ->
                CHANNEL.send(PacketDistributor.PLAYER.with(() -> sp), new SyncPacket(s.serializeNBT())));
    }
}
