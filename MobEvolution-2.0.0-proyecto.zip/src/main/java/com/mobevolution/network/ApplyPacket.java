package com.mobevolution.network;

import com.mobevolution.skills.PlayerSkillsProvider;
import com.mobevolution.skills.SkillEffects;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Cliente -> servidor: "Confirmar cambios" con los puntos repartidos. El servidor valida todo. */
public class ApplyPacket {
    private final int[] increments;

    public ApplyPacket(int[] increments) { this.increments = increments; }

    public static void encode(ApplyPacket m, FriendlyByteBuf b) {
        b.writeVarInt(m.increments.length);
        for (int v : m.increments) b.writeVarInt(v);
    }

    public static ApplyPacket decode(FriendlyByteBuf b) {
        int n = Math.max(0, Math.min(b.readVarInt(), 64));
        int[] a = new int[n];
        for (int i = 0; i < n; i++) a[i] = b.readVarInt();
        return new ApplyPacket(a);
    }

    public static void handle(ApplyPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp == null) return;
            sp.getCapability(PlayerSkillsProvider.CAP).ifPresent(s -> {
                if (s.applyIncrements(m.increments)) {
                    SkillEffects.apply(sp);
                    Network.sync(sp);
                }
            });
        });
        ctx.get().setPacketHandled(true);
    }
}
