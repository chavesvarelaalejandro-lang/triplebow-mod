package com.mobevolution.client;

import com.mobevolution.MobEvolution;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public class ClientEvents {
    public static final KeyMapping OPEN_SKILLS = new KeyMapping(
            "key.mobevolution.open", InputConstants.KEY_K, "key.categories.mobevolution");

    @Mod.EventBusSubscriber(modid = MobEvolution.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ModBus {
        @SubscribeEvent
        public static void keys(RegisterKeyMappingsEvent e) {
            e.register(OPEN_SKILLS);
        }
    }

    @Mod.EventBusSubscriber(modid = MobEvolution.MODID, value = Dist.CLIENT)
    public static class ForgeBus {
        @SubscribeEvent
        public static void tick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            while (OPEN_SKILLS.consumeClick()) {
                Minecraft mc = Minecraft.getInstance();
                if (mc.player != null && mc.screen == null) mc.setScreen(new SkillScreen());
            }
        }
    }
}
