package dev.triplebow;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Las 3 flechas llegan en el mismo tick, y Minecraft ignora los golpes que llegan
 * mientras el mob está en su "invulnerabilidad tras daño". Aquí la quitamos justo
 * antes de que impacte una flecha del Arco Triple para que las 3 hagan daño.
 */
@Mod.EventBusSubscriber(modid = TripleBowMod.MOD_ID)
public class TripleBowEvents {

	public static final String ARROW_TAG = "triplebow_arrow";

	@SubscribeEvent
	public static void onProjectileImpact(ProjectileImpactEvent event) {
		if (event.getProjectile().level().isClientSide) {
			return;
		}
		if (!event.getProjectile().getTags().contains(ARROW_TAG)) {
			return;
		}
		if (event.getRayTraceResult() instanceof EntityHitResult hit
				&& hit.getEntity() instanceof LivingEntity living) {
			living.invulnerableTime = 0;
		}
	}
}
