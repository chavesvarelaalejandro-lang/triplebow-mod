package dev.triplebow;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.ForgeEventFactory;

/**
 * Arco que dispara 3 flechas a la vez (gastando solo 1 flecha del inventario).
 * Salen en abanico: una central y una a cada lado (±10 grados).
 */
public class TripleBowItem extends BowItem {

	private static final float SPREAD_DEGREES = 10.0F;

	public TripleBowItem(Properties properties) {
		super(properties);
	}

	@Override
	public void releaseUsing(ItemStack bow, Level level, LivingEntity entity, int timeLeft) {
		if (!(entity instanceof Player player)) {
			return;
		}

		boolean infinity = player.getAbilities().instabuild
				|| EnchantmentHelper.getItemEnchantmentLevel(Enchantments.INFINITY_ARROWS, bow) > 0;
		ItemStack ammo = player.getProjectile(bow);

		int charge = this.getUseDuration(bow) - timeLeft;
		charge = ForgeEventFactory.onArrowLoose(bow, level, player, charge, !ammo.isEmpty() || infinity);
		if (charge < 0) {
			return;
		}
		if (ammo.isEmpty() && !infinity) {
			return;
		}
		if (ammo.isEmpty()) {
			ammo = new ItemStack(Items.ARROW);
		}

		float power = getPowerForTime(charge);
		if (power < 0.1F) {
			return;
		}

		boolean freeArrow = player.getAbilities().instabuild
				|| (ammo.getItem() instanceof ArrowItem arrowItem && arrowItem.isInfinite(ammo, bow, player));

		if (!level.isClientSide) {
			ArrowItem arrowItem = ammo.getItem() instanceof ArrowItem a ? a : (ArrowItem) Items.ARROW;

			int powerLevel = EnchantmentHelper.getItemEnchantmentLevel(Enchantments.POWER_ARROWS, bow);
			int punchLevel = EnchantmentHelper.getItemEnchantmentLevel(Enchantments.PUNCH_ARROWS, bow);
			boolean flame = EnchantmentHelper.getItemEnchantmentLevel(Enchantments.FLAMING_ARROWS, bow) > 0;

			for (int n = 0; n < 3; n++) {
				AbstractArrow arrow = arrowItem.createArrow(level, ammo, player);
				arrow = customArrow(arrow);

				float yawOffset = (n - 1) * SPREAD_DEGREES; // -10, 0, +10
				arrow.shootFromRotation(player, player.getXRot(), player.getYRot() + yawOffset, 0.0F, power * 3.0F, 1.0F);

				if (power == 1.0F) {
					arrow.setCritArrow(true);
				}
				if (powerLevel > 0) {
					arrow.setBaseDamage(arrow.getBaseDamage() + powerLevel * 0.5D + 0.5D);
				}
				if (punchLevel > 0) {
					arrow.setKnockback(punchLevel);
				}
				if (flame) {
					arrow.setSecondsOnFire(100);
				}

				// Solo la flecha central se puede recoger (evita duplicar flechas)
				if (freeArrow || n != 1) {
					arrow.pickup = AbstractArrow.Pickup.CREATIVE_ONLY;
				}

				level.addFreshEntity(arrow);
			}

			// 1 punto de durabilidad por disparo
			bow.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(player.getUsedItemHand()));
		}

		level.playSound(null, player.getX(), player.getY(), player.getZ(),
				SoundEvents.ARROW_SHOOT, SoundSource.PLAYERS,
				1.0F, 1.0F / (level.getRandom().nextFloat() * 0.4F + 1.2F) + power * 0.5F);

		if (!freeArrow && !player.getAbilities().instabuild) {
			ammo.shrink(1);
			if (ammo.isEmpty()) {
				player.getInventory().removeItem(ammo);
			}
		}

		player.awardStat(Stats.ITEM_USED.get(this));
	}
}
