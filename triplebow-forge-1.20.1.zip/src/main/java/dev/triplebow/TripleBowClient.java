package dev.triplebow;

import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = TripleBowMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class TripleBowClient {

	@SubscribeEvent
	public static void onClientSetup(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			// Animación de tensado (igual que el arco vanilla)
			ItemProperties.register(TripleBowMod.TRIPLE_BOW.get(), new ResourceLocation("pull"),
					(stack, level, entity, seed) -> {
						if (entity == null || entity.getUseItem() != stack) {
							return 0.0F;
						}
						return (stack.getUseDuration() - entity.getUseItemRemainingTicks()) / 20.0F;
					});

			ItemProperties.register(TripleBowMod.TRIPLE_BOW.get(), new ResourceLocation("pulling"),
					(stack, level, entity, seed) ->
							entity != null && entity.isUsingItem() && entity.getUseItem() == stack ? 1.0F : 0.0F);
		});
	}
}
